function ErrorNode = HistGetBound( weight )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
SortWeight = sort(weight);
Bound = [ 0 0 ];
for 1:length(SortWeight)
    
end

end

