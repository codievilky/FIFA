function Distance = GetDistance( A , B )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
Distance = sqrt( (A(1) - B(1)) * (A(1) - B(1)) + (A(2) - B(2)) * (A(2) - B(2)) );

end

