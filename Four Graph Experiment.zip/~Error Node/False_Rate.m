function [FPR,FNR]=False_Rate(Standed,Calculated)
%False Positive Rate �鱨��
FPR=False_Positive_Rate(Standed,Calculated);
%False Negative Rate ����
FNR=False_Negative_Rate(Standed,Calculated);